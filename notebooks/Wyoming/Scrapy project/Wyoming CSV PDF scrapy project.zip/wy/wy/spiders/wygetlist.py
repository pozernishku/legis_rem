# -*- coding: utf-8 -*-
# Notes
# Run this spider first. It will create a correct sequence list of links (comms.csv). It's needed only for 
# this site because of 500 server error. Run wyst.py spider after this one.
# Both spiders work with this setting CONCURRENT_REQUESTS = 1
# Change start_urls from this list http://legisweb.state.wy.us/LSOWEB/Interim.aspx one by one manualy to avoid server errors.
# Comment this line FEED_EXPORT_FIELDS = ['committee', 'date', 'filename', 'url'] before starting the spider.
import scrapy

class WygetlistSpider(scrapy.Spider):
    name = 'wygetlist'
    allowed_domains = ['legisweb.state.wy.us']
    start_urls = [
        'https://legisweb.state.wy.us/LegbyYear/IntCommList.aspx?Year=2016'
        #'https://legisweb.state.wy.us/LegbyYear/IntCommList.aspx?Year=2015'
        #'https://legisweb.state.wy.us/LegislatorSummary/IntCommList.aspx'
        ]

    def parse(self, response):
        links = response.xpath('//a[contains(@href, "strCommitteeID=")]/@href').extract()
        for link in links:
            yield response.follow(link, callback=self.parse_mins, dont_filter=True)

    def parse_mins(self, response):
        yield {'url': response.url }

        mins_link = response.xpath('//a[@id="ctl00_cphContent_hlMinutes"]/@href').extract_first()
        
        mins_link = response.urljoin(mins_link) if mins_link is not None else None

        yield {'url': mins_link }